package com.cu.template.model.type;

public enum ProjectRole {
    Guest, Reporter, Developer, Maintainer
}
