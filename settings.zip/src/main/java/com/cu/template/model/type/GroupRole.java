package com.cu.template.model.type;

public enum GroupRole {
    Guest, Reporter, Developer, Maintainer
}
